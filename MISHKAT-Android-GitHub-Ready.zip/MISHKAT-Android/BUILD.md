# Building the APK

## GitHub Actions (recommended on a phone)
Use `.github/workflows/build.yml`. It prepares the Quran and Hisn al-Muslim assets, installs the Android SDK, and runs `:app:assembleDebug`. The real APK is uploaded as a GitHub Actions artifact.

## Local Android Studio
Open this directory as an Android project. Use JDK 17 and a Gradle/AGP combination compatible with AGP 9.4.0. Before the first build, run:

```bash
python3 scripts/prepare_content.py
gradle :app:assembleDebug
```

Generated content is intentionally ignored by Git because it is acquired at build time from its declared sources.
