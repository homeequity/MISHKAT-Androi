# مِشكاة – MISHKAT

Native Android app built with Kotlin + Jetpack Compose, designed as an offline-first Islamic application.

## Important

This repository intentionally does **not** commit placeholder Quran or dhikr data. The build workflow downloads and validates the declared third-party sources, then generates the local JSON assets before compiling the APK.

- Quran text: Tanzil Project Uthmani text. The Tanzil terms allow verbatim use in applications with clear attribution and a link to tanzil.net; changing the Quran text is not permitted.
- Dhikr data: HisnElMuslim open-source JSON repository. The current repository page identifies an MIT license; review the upstream license before shipping any derivative distribution.
- Alafasy recordings are **not bundled** unless the developer supplies recordings with redistribution rights.

## Build APK on GitHub from a phone

1. Create an empty GitHub repository.
2. Upload the contents of this folder, including `.github/workflows/build.yml` and `scripts/prepare_content.py`.
3. Open the repository on GitHub → **Actions** → **MISHKAT Android APK** → **Run workflow**.
4. When the workflow finishes, open the workflow run → **Artifacts** → **MISHKAT-debug-apk**.
5. Download the artifact ZIP and extract `app-debug.apk` on the phone.

The workflow uses JDK 17, Gradle 9.6 and Android SDK 36.

## Project structure

- `app/src/main/java/com/mishkat/app/data` – Room database and repository.
- `app/src/main/java/com/mishkat/app/domain` – prayer, qibla, audio and reminder infrastructure.
- `app/src/main/java/com/mishkat/app/ui` – Compose UI and navigation.
- `scripts/prepare_content.py` – build-time content acquisition and validation.

## Current implementation boundary

The scaffold contains the real Android shell, local database, Quran/dhikr ingestion pipeline, prayer calculation foundation, qibla sensor foundation, Media3 playback service foundation, crash-safe permission handling and GitHub Actions APK build.

Before publishing as a true production release, complete and manually verify the remaining product surfaces requested in the specification: full audio catalog/player UI, recurring notification scheduling UI, manual city/country settings, unified search UI, export/import backup UI, complete bookmarks/favorites/last-read screens, tafsir package with a valid license, and final device/regression testing.
