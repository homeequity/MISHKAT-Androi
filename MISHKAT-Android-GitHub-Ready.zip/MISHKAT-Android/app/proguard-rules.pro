# MISHKAT custom R8 rules.
# Keep Room entities/DAOs and Media3 service metadata safe in release builds.
-keep class com.mishkat.app.data.db.** { *; }
-keep class androidx.room.** { *; }
-keep class androidx.media3.** { *; }
