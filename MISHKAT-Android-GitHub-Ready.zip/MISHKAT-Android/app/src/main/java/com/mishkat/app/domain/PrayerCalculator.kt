package com.mishkat.app.domain

import java.time.*
import kotlin.math.*

data class PrayerTimes(
    val fajr: LocalTime,
    val sunrise: LocalTime,
    val dhuhr: LocalTime,
    val asr: LocalTime,
    val maghrib: LocalTime,
    val isha: LocalTime
)

enum class CalculationMethod(val label: String, val fajrAngle: Double, val ishaAngle: Double, val ishaMinutes: Double = 0.0) {
    MUSLIM_WORLD_LEAGUE("رابطة العالم الإسلامي", 18.0, 17.0),
    EGYPTIAN("الهيئة المصرية", 19.5, 17.5),
    KARACHI("كراتشي", 18.0, 18.0),
    ISNA("ISNA", 15.0, 15.0),
    UMM_AL_QURA("أم القرى", 18.5, 0.0, 90.0)
}

enum class Madhab(val shadow: Double, val label: String) { SHAFI(1.0, "شافعي"), HANAFI(2.0, "حنفي") }

data class CityLocation(val name: String, val latitude: Double, val longitude: Double, val zone: String = "Asia/Aden")

object CityCatalog {
    val defaults = listOf(
        CityLocation("صنعاء", 15.3694, 44.1910),
        CityLocation("عدن", 12.7855, 45.0187),
        CityLocation("تعز", 13.5789, 44.0219),
        CityLocation("إب", 13.9667, 44.1833),
        CityLocation("الحديدة", 14.7978, 42.9545),
        CityLocation("المكلا", 14.5425, 49.1242)
    )
}

object PrayerCalculator {
    fun calculate(date: LocalDate, location: CityLocation, method: CalculationMethod, madhab: Madhab): PrayerTimes {
        val jd = julianDay(date)
        val decl = solarDeclination(jd)
        val eqt = equationOfTime(jd)
        val tz = ZoneId.of(location.zone).rules.getOffset(date.atTime(12, 0)).totalSeconds / 3600.0
        val noonMinutes = 720.0 - 4.0 * location.longitude - eqt + tz * 60.0
        val sunrise = solarTimeForAngle(location.latitude, decl, -0.833, noonMinutes, true)
        val sunset = solarTimeForAngle(location.latitude, decl, -0.833, noonMinutes, false)
        val fajr = solarTimeForAngle(location.latitude, decl, -method.fajrAngle, noonMinutes, true)
        val isha = if (method.ishaMinutes > 0) sunset + method.ishaMinutes else solarTimeForAngle(location.latitude, decl, -method.ishaAngle, noonMinutes, false)
        val asrAlt = Math.toDegrees(atan(1.0 / (madhab.shadow + shadowLength(location.latitude, decl, noonMinutes))))
        val asr = solarTimeForAngle(location.latitude, decl, asrAlt, noonMinutes, false)
        return PrayerTimes(
            fajr.toLocalTimeOfDay(),
            sunrise.toLocalTimeOfDay(),
            noonMinutes.toLocalTimeOfDay(),
            asr.toLocalTimeOfDay(),
            sunset.toLocalTimeOfDay(),
            isha.toLocalTimeOfDay()
        )
    }

    private fun julianDay(date: LocalDate): Double {
        val y = date.year
        val m = date.monthValue
        val d = date.dayOfMonth
        val a = (14 - m) / 12
        val yy = y + 4800 - a
        val mm = m + 12 * a - 3
        val jdn = d + (153 * mm + 2) / 5 + 365 * yy + yy / 4 - yy / 100 + yy / 400 - 32045
        return jdn - 0.5
    }

    private fun solarDeclination(jd: Double): Double {
        val t = (jd - 2451545.0) / 36525.0
        val l0 = normalize(280.46646 + 36000.76983 * t + 0.0003032 * t * t)
        val m = normalize(357.52911 + 35999.05029 * t - 0.0001537 * t * t)
        val e = 23.439291 - 0.0130042 * t
        val c = (1.914602 - 0.004817 * t - 0.000014 * t * t) * sin(Math.toRadians(m)) +
                (0.019993 - 0.000101 * t) * sin(Math.toRadians(2 * m)) +
                0.000289 * sin(Math.toRadians(3 * m))
        val lambda = l0 + c
        return Math.toDegrees(asin(sin(Math.toRadians(e)) * sin(Math.toRadians(lambda))))
    }

    private fun equationOfTime(jd: Double): Double {
        val t = (jd - 2451545.0) / 36525.0
        val epsilon = 23.439291 - 0.0130042 * t
        val l0 = normalize(280.46646 + 36000.76983 * t + 0.0003032 * t * t)
        val m = normalize(357.52911 + 35999.05029 * t - 0.0001537 * t * t)
        val e = 0.016708634 - 0.000042037 * t
        val y = tan(Math.toRadians(epsilon) / 2).pow(2)
        val eq = y * sin(2 * Math.toRadians(l0)) -
                2 * e * sin(Math.toRadians(m)) +
                4 * e * y * sin(Math.toRadians(m)) * cos(2 * Math.toRadians(l0)) -
                0.5 * y.pow(2) * sin(4 * Math.toRadians(l0)) -
                1.25 * e.pow(2) * sin(2 * Math.toRadians(m))
        return Math.toDegrees(eq) * 4.0
    }

    private fun solarTimeForAngle(lat: Double, decl: Double, angle: Double, noon: Double, morning: Boolean): Double {
        val latR = Math.toRadians(lat)
        val decR = Math.toRadians(decl)
        val angleR = Math.toRadians(angle)
        val cosH = (sin(angleR) - sin(latR) * sin(decR)) / (cos(latR) * cos(decR))
        val h = Math.toDegrees(acos(cosH.coerceIn(-1.0, 1.0)))
        return if (morning) noon - h * 4.0 else noon + h * 4.0
    }

    private fun shadowLength(lat: Double, decl: Double, noon: Double): Double {
        val solarNoon = noon / 60.0
        val ha = Math.toRadians((solarNoon - 12.0) * 15.0)
        val altitude = Math.toDegrees(asin(sin(Math.toRadians(lat)) * sin(Math.toRadians(decl)) + cos(Math.toRadians(lat)) * cos(Math.toRadians(decl)) * cos(ha)))
        return max(0.1, 1.0 / tan(Math.toRadians(altitude)))
    }

    private fun Double.toLocalTimeOfDay(): LocalTime {
        var mins = round(this).toInt() % 1440
        if (mins < 0) mins += 1440
        return LocalTime.of(mins / 60, mins % 60)
    }

    private fun normalize(v: Double): Double = ((v % 360.0) + 360.0) % 360.0
}
