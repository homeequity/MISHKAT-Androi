package com.mishkat.app

import android.app.Application
import com.mishkat.app.data.db.MishkatDatabase
import com.mishkat.app.data.repository.MishkatRepository

class MishkatApplication : Application() {
    val database by lazy { MishkatDatabase.get(this) }
    val repository by lazy { MishkatRepository(this, database) }

    override fun onCreate() {
        super.onCreate()
        repository.ensureSeeded()
    }
}
