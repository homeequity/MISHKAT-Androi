package com.mishkat.app.data.repository

import android.content.Context
import com.mishkat.app.data.db.*
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.Flow
import org.json.JSONObject

class MishkatRepository(
    private val context: Context,
    private val db: MishkatDatabase
) {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val seedMutex = Mutex()

    val surahs: Flow<List<QuranSurahEntity>> = db.quranDao().observeSurahs()
    val azkarCategories: Flow<List<AzkarCategoryEntity>> = db.azkarDao().observeCategories()

    fun observeAyahs(surah: Int): Flow<List<QuranAyahEntity>> = db.quranDao().observeAyahs(surah)
    fun observeAzkarItems(categoryId: Long): Flow<List<AzkarItemEntity>> = db.azkarDao().observeItems(categoryId)

    suspend fun searchQuran(q: String) = db.quranDao().search(q)
    suspend fun searchAzkar(q: String) = db.azkarDao().search(q)

    suspend fun toggleBookmark(surah: Int, ayah: Int) {
        if (db.userDao().hasBookmark(surah, ayah)) db.userDao().deleteBookmark(surah, ayah)
        else db.userDao().saveBookmark(BookmarkEntity(surah, ayah, System.currentTimeMillis()))
    }

    suspend fun toggleFavorite(surah: Int, ayah: Int) {
        if (db.userDao().hasFavorite(surah, ayah)) db.userDao().deleteFavorite(surah, ayah)
        else db.userDao().saveFavorite(FavoriteAyahEntity(surah, ayah, System.currentTimeMillis()))
    }

    suspend fun hasBookmark(surah: Int, ayah: Int) = db.userDao().hasBookmark(surah, ayah)
    suspend fun hasFavorite(surah: Int, ayah: Int) = db.userDao().hasFavorite(surah, ayah)

    suspend fun saveSetting(key: String, value: String) = db.userDao().saveSetting(UserSettingEntity(key, value))
    suspend fun getSetting(key: String) = db.userDao().getSetting(key)

    suspend fun getTasbeeh(): TasbeehStateEntity = db.userDao().getTasbeeh() ?: TasbeehStateEntity()
    suspend fun saveTasbeeh(state: TasbeehStateEntity) = db.userDao().saveTasbeeh(state)

    fun ensureSeeded() {
        scope.launch { seedMutex.withLock { seedIfNeeded() } }
    }

    private suspend fun seedIfNeeded() {
        if (db.metaDao().get("content_seed") == "1") return
        val assets = context.assets
        val quranJson = runCatching { assets.open("quran_seed.json") }.getOrNull()
        val azkarJson = runCatching { assets.open("azkar_seed.json") }.getOrNull()
        if (quranJson == null || azkarJson == null) return

        quranJson.bufferedReader().use { reader ->
            val root = JSONObject(reader.readText())
            val surahsArray = root.getJSONArray("surahs")
            val surahs = buildList {
                for (i in 0 until surahsArray.length()) {
                    val s = surahsArray.getJSONObject(i)
                    add(QuranSurahEntity(s.getInt("number"), s.getString("nameArabic"), s.getString("revelation"), s.getInt("ayahCount")))
                }
            }
            val ayahsArray = root.getJSONArray("ayahs")
            val ayahs = buildList {
                for (i in 0 until ayahsArray.length()) {
                    val a = ayahsArray.getJSONObject(i)
                    add(QuranAyahEntity(a.getInt("surah"), a.getInt("ayah"), a.getString("text"), a.optInt("page", 0)))
                }
            }
            db.quranDao().insertSurahs(surahs)
            ayahs.chunked(500).forEach { db.quranDao().insertAyahs(it) }
        }

        azkarJson.bufferedReader().use { reader ->
            val root = JSONObject(reader.readText())
            val categories = root.keys().asSequence().toList()
            val categoryEntities = categories.mapIndexed { index, title ->
                val category = root.getJSONObject(title)
                AzkarCategoryEntity(title = title, audioReference = null, sortOrder = index)
            }
            val ids = db.azkarDao().insertCategories(categoryEntities)
            val items = buildList {
                categories.forEachIndexed { idx, title ->
                    val category = root.getJSONObject(title)
                    val arr = category.getJSONArray("Adhkar")
                    for (i in 0 until arr.length()) {
                        val item = arr.getJSONObject(i)
                        add(AzkarItemEntity(
                            categoryId = ids[idx],
                            text = item.getString("Text"),
                            repeatCount = item.optInt("Count", 1).coerceAtLeast(1),
                            reference = item.optString("Reference", "مصدر حصن المسلم"),
                            sortOrder = i
                        ))
                    }
                }
            }
            items.chunked(300).forEach { db.azkarDao().insertItems(it) }
        }
        db.userDao().saveTasbeeh(TasbeehStateEntity())
        db.metaDao().put(MetaEntity("content_seed", "1"))
    }
}
