package com.mishkat.app.domain

import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import androidx.core.app.NotificationCompat
import com.mishkat.app.R

class ReminderReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val manager = context.getSystemService(NotificationManager::class.java)
        val channel = NotificationChannel(
            "mishkat_reminders",
            context.getString(R.string.notification_channel_name),
            NotificationManager.IMPORTANCE_DEFAULT
        ).apply { description = context.getString(R.string.notification_channel_description) }
        manager.createNotificationChannel(channel)
        val notification = NotificationCompat.Builder(context, "mishkat_reminders")
            .setSmallIcon(R.drawable.ic_launcher_mishkat)
            .setContentTitle("مِشكاة")
            .setContentText(intent.getStringExtra("text") ?: "تذكير من مِشكاة")
            .setAutoCancel(true)
            .build()
        manager.notify((System.currentTimeMillis() % Int.MAX_VALUE).toInt(), notification)
    }
}
