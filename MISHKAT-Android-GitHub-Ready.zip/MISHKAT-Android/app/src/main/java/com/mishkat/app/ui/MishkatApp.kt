package com.mishkat.app.ui

import android.Manifest
import android.app.Activity
import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.location.LocationManager
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.navigation.NavDestination.Companion.hasRoute
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.mishkat.app.MishkatApplication
import com.mishkat.app.data.db.*
import com.mishkat.app.data.repository.MishkatRepository
import com.mishkat.app.domain.*
import com.mishkat.app.ui.theme.MishkatTheme
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.time.Duration
import java.time.LocalDate
import java.time.LocalDateTime
import java.time.LocalTime
import java.time.format.DateTimeFormatter
import kotlin.math.roundToInt

private val formatter = DateTimeFormatter.ofPattern("HH:mm")

private sealed class Screen(val route: String, val label: String) {
    data object Home : Screen("home", "الرئيسية")
    data object Quran : Screen("quran", "القرآن")
    data object Azkar : Screen("azkar", "الأذكار")
    data object Qibla : Screen("qibla", "القبلة")
    data object More : Screen("more", "المزيد")
}

@Composable
fun MishkatApp() {
    val context = LocalContext.current
    val app = context.applicationContext as MishkatApplication
    var darkTheme by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) {
        darkTheme = app.repository.getSetting("dark_mode")?.toBooleanStrictOrNull() ?: false
    }

    MishkatTheme(darkTheme = darkTheme) {
        val nav = rememberNavController()
        val scope = rememberCoroutineScope()
        val screens = listOf(Screen.Home, Screen.Quran, Screen.Azkar, Screen.Qibla, Screen.More)
        val backStack by nav.currentBackStackEntryAsState()
        val currentRoute = backStack?.destination?.route

        Scaffold(
            containerColor = MaterialTheme.colorScheme.background,
            bottomBar = {
                NavigationBar {
                    screens.forEach { screen ->
                        val selected = currentRoute == screen.route
                        NavigationBarItem(
                            selected = selected,
                            onClick = { nav.navigate(screen.route) { launchSingleTop = true; restoreState = true } },
                            icon = {
                                Icon(
                                    when (screen) {
                                        Screen.Home -> Icons.Default.Home
                                        Screen.Quran -> Icons.Default.MenuBook
                                        Screen.Azkar -> Icons.Default.Favorite
                                        Screen.Qibla -> Icons.Default.Explore
                                        Screen.More -> Icons.Default.MoreHoriz
                                    },
                                    contentDescription = screen.label
                                )
                            },
                            label = { Text(screen.label) }
                        )
                    }
                }
            }
        ) { padding ->
            NavHost(navController = nav, startDestination = Screen.Home.route, modifier = Modifier.padding(padding)) {
                composable(Screen.Home.route) { HomeScreen(nav, app.repository, darkTheme) }
                composable(Screen.Quran.route) { QuranScreen(nav, app.repository) }
                composable("quran/{surah}") { entry ->
                    val surah = entry.arguments?.getString("surah")?.toIntOrNull() ?: 1
                    QuranReaderScreen(nav, app.repository, surah)
                }
                composable(Screen.Azkar.route) { AzkarScreen(nav, app.repository) }
                composable("azkar/{categoryId}") { entry ->
                    val id = entry.arguments?.getString("categoryId")?.toLongOrNull() ?: 0L
                    AzkarReaderScreen(nav, app.repository, id)
                }
                composable(Screen.Qibla.route) { QiblaScreen() }
                composable(Screen.More.route) {
                    MoreScreen(
                        darkTheme = darkTheme,
                        onDarkModeChange = { dark ->
                            darkTheme = dark
                            scope.launch { app.repository.saveSetting("dark_mode", dark.toString()) }
                        }
                    )
                }
            }
        }
    }
}

@Composable
private fun Header(title: String, subtitle: String? = null, onBack: (() -> Unit)? = null) {
    Row(modifier = Modifier.fillMaxWidth().padding(20.dp), verticalAlignment = Alignment.CenterVertically) {
        if (onBack != null) {
            IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, contentDescription = "رجوع") }
            Spacer(Modifier.width(4.dp))
        }
        Column(Modifier.weight(1f)) {
            Text(title, fontSize = 28.sp, fontWeight = FontWeight.Bold)
            if (subtitle != null) Text(subtitle, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.65f))
        }
    }
}

@Composable
private fun HomeScreen(nav: NavHostController, repo: MishkatRepository, darkTheme: Boolean) {
    val context = LocalContext.current
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { }
    val prayer = remember { mutableStateOf<PrayerTimes?>(null) }
    var now by remember { mutableStateOf(LocalDateTime.now()) }
    var cityName by remember { mutableStateOf("صنعاء") }
    LaunchedEffect(Unit) {
        while (true) { now = LocalDateTime.now(); delay(1000) }
    }
    LaunchedEffect(Unit) {
        val city = CityCatalog.defaults.first()
        prayer.value = PrayerCalculator.calculate(LocalDate.now(), city, CalculationMethod.MUSLIM_WORLD_LEAGUE, Madhab.SHAFI)
    }

    val times = prayer.value
    val next = times?.let { nextPrayer(now.toLocalTime(), it) }

    LazyColumn(contentPadding = PaddingValues(bottom = 24.dp)) {
        item {
            Column(Modifier.padding(horizontal = 20.dp)) {
                Spacer(Modifier.height(18.dp))
                Text("مِشكاة", color = MaterialTheme.colorScheme.primary, fontSize = 20.sp, fontWeight = FontWeight.SemiBold)
                Text("نورٌ لقلبك.. في كل حين", color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.65f))
                Spacer(Modifier.height(18.dp))
                Surface(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(28.dp),
                    color = MaterialTheme.colorScheme.primary
                ) {
                    Column(Modifier.padding(22.dp)) {
                        Text("الصلاة القادمة", color = MaterialTheme.colorScheme.onPrimary.copy(alpha = 0.75f))
                        Text(next?.first ?: "—", color = MaterialTheme.colorScheme.onPrimary, fontSize = 30.sp, fontWeight = FontWeight.Bold)
                        Text(next?.let { formatCountdown(it.second, now) } ?: "—", color = MaterialTheme.colorScheme.secondary, fontSize = 24.sp, fontWeight = FontWeight.SemiBold)
                        Spacer(Modifier.height(14.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                            times?.let {
                                PrayerChip("الفجر", it.fajr)
                                PrayerChip("الظهر", it.dhuhr)
                                PrayerChip("العصر", it.asr)
                                PrayerChip("المغرب", it.maghrib)
                                PrayerChip("العشاء", it.isha)
                            }
                        }
                    }
                }
                Spacer(Modifier.height(16.dp))
                Surface(shape = RoundedCornerShape(20.dp), color = MaterialTheme.colorScheme.surfaceContainer, modifier = Modifier.fillMaxWidth()) {
                    Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Place, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                        Spacer(Modifier.width(10.dp))
                        Column(Modifier.weight(1f)) {
                            Text("الموقع الحالي")
                            Text(cityName, fontWeight = FontWeight.Bold)
                        }
                        TextButton(onClick = {
                            val perms = mutableListOf(Manifest.permission.ACCESS_COARSE_LOCATION, Manifest.permission.ACCESS_FINE_LOCATION)
                            launcher.launch(perms.toTypedArray())
                        }) { Text("تحديد") }
                    }
                }
                Spacer(Modifier.height(22.dp))
                Text("الوصول السريع", fontSize = 20.sp, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(10.dp))
            }
        }
        item { QuickActionGrid(nav) }
    }
}

@Composable
private fun RowScope.PrayerChip(name: String, time: LocalTime) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(name, color = MaterialTheme.colorScheme.onPrimary.copy(alpha = 0.75f), fontSize = 12.sp)
        Text(time.format(formatter), color = MaterialTheme.colorScheme.onPrimary, fontWeight = FontWeight.Bold)
    }
    Spacer(Modifier.width(2.dp))
}

private fun nextPrayer(now: LocalTime, t: PrayerTimes): Pair<String, LocalTime>? {
    val prayers = listOf("الفجر" to t.fajr, "الشروق" to t.sunrise, "الظهر" to t.dhuhr, "العصر" to t.asr, "المغرب" to t.maghrib, "العشاء" to t.isha)
    return prayers.firstOrNull { it.second.isAfter(now) } ?: prayers.firstOrNull()
}

private fun formatCountdown(target: LocalTime, now: LocalDateTime): String {
    var targetDt = now.toLocalDate().atTime(target)
    if (!targetDt.isAfter(now)) targetDt = targetDt.plusDays(1)
    val seconds = Duration.between(now, targetDt).seconds.coerceAtLeast(0)
    val h = seconds / 3600
    val m = (seconds % 3600) / 60
    val s = seconds % 60
    return "%02d:%02d:%02d".format(h, m, s)
}

@Composable
private fun QuickActionGrid(nav: NavHostController) {
    Column(Modifier.padding(horizontal = 20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            QuickCard(Modifier.weight(1f), "القرآن", Icons.Default.MenuBook) { nav.navigate("quran") }
            QuickCard(Modifier.weight(1f), "الأذكار", Icons.Default.Favorite) { nav.navigate("azkar") }
        }
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            QuickCard(Modifier.weight(1f), "القبلة", Icons.Default.Explore) { nav.navigate("qibla") }
            QuickCard(Modifier.weight(1f), "السبحة", Icons.Default.AddCircle) { /* More screen contains tasbeeh access */ nav.navigate("more") }
        }
    }
}

@Composable
private fun QuickCard(modifier: Modifier, title: String, icon: androidx.compose.ui.graphics.vector.ImageVector, onClick: () -> Unit) {
    Surface(modifier = modifier.height(110.dp).clickable(onClick = onClick), shape = RoundedCornerShape(22.dp), color = MaterialTheme.colorScheme.surface) {
        Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.SpaceBetween) {
            Icon(icon, contentDescription = title, tint = MaterialTheme.colorScheme.primary)
            Text(title, fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
private fun QuranScreen(nav: NavHostController, repo: MishkatRepository) {
    val surahs by repo.surahs.collectAsState(initial = emptyList())
    Column(Modifier.fillMaxSize()) {
        Header("القرآن الكريم", "قراءة محلية بدون إنترنت")
        if (surahs.isEmpty()) {
            LoadingContent("جاري تجهيز المصحف داخل التطبيق…")
        } else {
            LazyColumn(contentPadding = PaddingValues(horizontal = 20.dp, vertical = 4.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                items(surahs) { surah ->
                    Surface(
                        modifier = Modifier.fillMaxWidth().clickable { nav.navigate("quran/${surah.number}") },
                        shape = RoundedCornerShape(18.dp),
                        color = MaterialTheme.colorScheme.surface
                    ) {
                        Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                            Surface(shape = RoundedCornerShape(12.dp), color = MaterialTheme.colorScheme.primaryContainer) {
                                Text(surah.number.toString(), modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp), fontWeight = FontWeight.Bold)
                            }
                            Spacer(Modifier.width(14.dp))
                            Column(Modifier.weight(1f)) {
                                Text(surah.nameArabic, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                                Text("${surah.revelation} • ${surah.ayahCount} آية", color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.65f))
                            }
                            Icon(Icons.Default.ChevronLeft, contentDescription = null)
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun QuranReaderScreen(nav: NavHostController, repo: MishkatRepository, surah: Int) {
    val ayahs by repo.observeAyahs(surah).collectAsState(initial = emptyList())
    val title by repo.surahs.collectAsState(initial = emptyList())
    val surahName = title.firstOrNull { it.number == surah }?.nameArabic ?: "السورة"
    Column(Modifier.fillMaxSize()) {
        Header(surahName, "مصحف مِشكاة • قراءة Offline") { nav.popBackStack() }
        if (ayahs.isEmpty()) LoadingContent("جاري تحميل الآيات…") else {
            LazyColumn(contentPadding = PaddingValues(horizontal = 20.dp, vertical = 6.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                items(ayahs) { ayah ->
                    QuranAyahCard(ayah, repo)
                }
            }
        }
    }
}

@Composable
private fun QuranAyahCard(ayah: QuranAyahEntity, repo: MishkatRepository) {
    var bookmarked by remember { mutableStateOf(false) }
    var favorite by remember { mutableStateOf(false) }
    LaunchedEffect(ayah.surah, ayah.ayah) {
        bookmarked = repo.hasBookmark(ayah.surah, ayah.ayah)
        favorite = repo.hasFavorite(ayah.surah, ayah.ayah)
    }
    Surface(shape = RoundedCornerShape(22.dp), color = MaterialTheme.colorScheme.surface, modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(20.dp)) {
            Text(ayah.text, fontSize = 25.sp, lineHeight = 46.sp, textAlign = TextAlign.Right, modifier = Modifier.fillMaxWidth())
            Spacer(Modifier.height(10.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(if (ayah.page > 0) "آية ${ayah.ayah} • صفحة ${ayah.page}" else "آية ${ayah.ayah}", color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f), modifier = Modifier.weight(1f))
                IconButton(onClick = {
                    bookmarked = !bookmarked
                    kotlinx.coroutines.GlobalScope.launch { repo.toggleBookmark(ayah.surah, ayah.ayah) }
                }) { Icon(if (bookmarked) Icons.Default.Bookmark else Icons.Default.BookmarkBorder, contentDescription = "علامة") }
                IconButton(onClick = {
                    favorite = !favorite
                    kotlinx.coroutines.GlobalScope.launch { repo.toggleFavorite(ayah.surah, ayah.ayah) }
                }) { Icon(if (favorite) Icons.Default.Favorite else Icons.Default.FavoriteBorder, contentDescription = "مفضلة") }
            }
        }
    }
}

@Composable
private fun AzkarScreen(nav: NavHostController, repo: MishkatRepository) {
    val cats by repo.azkarCategories.collectAsState(initial = emptyList())
    Column(Modifier.fillMaxSize()) {
        Header("الأذكار", "حصن المسلم • نصوص موثقة ومخزنة محليًا")
        if (cats.isEmpty()) LoadingContent("جاري تجهيز الأذكار…") else {
            LazyColumn(contentPadding = PaddingValues(horizontal = 20.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                items(cats) { cat ->
                    Surface(modifier = Modifier.fillMaxWidth().clickable { nav.navigate("azkar/${cat.id}") }, shape = RoundedCornerShape(20.dp), color = MaterialTheme.colorScheme.surface) {
                        Row(Modifier.padding(18.dp), verticalAlignment = Alignment.CenterVertically) {
                            Surface(shape = RoundedCornerShape(14.dp), color = MaterialTheme.colorScheme.primaryContainer) {
                                Icon(Icons.Default.AutoAwesome, contentDescription = null, modifier = Modifier.padding(12.dp), tint = MaterialTheme.colorScheme.primary)
                            }
                            Spacer(Modifier.width(14.dp))
                            Text(cat.title, Modifier.weight(1f), fontSize = 18.sp, fontWeight = FontWeight.SemiBold)
                            Icon(Icons.Default.ChevronLeft, contentDescription = null)
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun AzkarReaderScreen(nav: NavHostController, repo: MishkatRepository, categoryId: Long) {
    val cats by repo.azkarCategories.collectAsState(initial = emptyList())
    val items by repo.observeAzkarItems(categoryId).collectAsState(initial = emptyList())
    val title = cats.firstOrNull { it.id == categoryId }?.title ?: "الذكر"
    Column(Modifier.fillMaxSize()) {
        Header(title, "القراءة والعدّ تعمل بدون إنترنت") { nav.popBackStack() }
        if (items.isEmpty()) LoadingContent("جاري تحميل الأذكار…") else {
            LazyColumn(contentPadding = PaddingValues(horizontal = 20.dp, vertical = 4.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                items(items) { item -> DhikrCard(item) }
            }
        }
    }
}

@Composable
private fun DhikrCard(item: AzkarItemEntity) {
    var count by rememberSaveable(item.id) { mutableStateOf(0) }
    val target = item.repeatCount.coerceAtLeast(1)
    Surface(shape = RoundedCornerShape(22.dp), color = MaterialTheme.colorScheme.surface, modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(20.dp)) {
            Text(item.text, fontSize = 23.sp, lineHeight = 42.sp, textAlign = TextAlign.Right, modifier = Modifier.fillMaxWidth())
            Spacer(Modifier.height(12.dp))
            Text("المصدر: ${item.reference}", fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.62f))
            Spacer(Modifier.height(14.dp))
            Text("عدد التكرار: $count / $target", fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
            Spacer(Modifier.height(10.dp))
            Button(onClick = { count = if (count >= target) 0 else count + 1 }, modifier = Modifier.fillMaxWidth().height(54.dp)) {
                Text(if (count >= target) "إعادة العداد" else "تسبيح • ${count + 1}")
            }
            if (count >= target) {
                Spacer(Modifier.height(6.dp))
                Text("أتممت هذا الذكر", color = MaterialTheme.colorScheme.secondary, modifier = Modifier.fillMaxWidth(), textAlign = TextAlign.Center)
            }
        }
    }
}

@Composable
private fun QiblaScreen() {
    val context = LocalContext.current
    var location by remember { mutableStateOf<Pair<Double, Double>?>(null) }
    var bearing by remember { mutableStateOf(0f) }
    var azimuth by remember { mutableStateOf<Float?>(null) }
    val locationLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
        location = getLastLocation(context)
        location?.let { bearing = QiblaCalculator.bearingFrom(it.first, it.second) }
    }
    LaunchedEffect(Unit) {
        location = getLastLocation(context)
        location?.let { bearing = QiblaCalculator.bearingFrom(it.first, it.second) }
    }

    DisposableEffect(Unit) {
        val sensorManager = context.getSystemService(Context.SENSOR_SERVICE) as SensorManager
        val rotation = sensorManager.getDefaultSensor(Sensor.TYPE_ROTATION_VECTOR)
        val listener = object : SensorEventListener {
            override fun onSensorChanged(event: SensorEvent) {
                val rotationMatrix = FloatArray(9)
                SensorManager.getRotationMatrixFromVector(rotationMatrix, event.values)
                val orientation = FloatArray(3)
                SensorManager.getOrientation(rotationMatrix, orientation)
                azimuth = ((Math.toDegrees(orientation[0].toDouble()).toFloat() + 360f) % 360f)
            }
            override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) = Unit
        }
        rotation?.let { sensorManager.registerListener(listener, it, SensorManager.SENSOR_DELAY_UI) }
        onDispose { sensorManager.unregisterListener(listener) }
    }

    val relative = azimuth?.let { ((bearing - it + 540f) % 360f) - 180f } ?: 0f
    Column(Modifier.fillMaxSize(), horizontalAlignment = Alignment.CenterHorizontally) {
        Header("اتجاه القبلة", "حرّك هاتفك حتى تتجه العلامة إلى القبلة")
        Surface(shape = RoundedCornerShape(32.dp), color = MaterialTheme.colorScheme.surfaceContainer, modifier = Modifier.padding(20.dp).fillMaxWidth()) {
            Column(Modifier.padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                if (location == null) {
                    Text("لم نتمكن من تحديد موقعك", fontSize = 18.sp, fontWeight = FontWeight.Bold)
                    Text("يمكنك تفعيل الموقع أو اختيار الموقع يدويًا.", textAlign = TextAlign.Center, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.65f))
                    Spacer(Modifier.height(12.dp))
                    Button(onClick = { locationLauncher.launch(arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION)) }) { Text("تحديد الموقع") }
                } else if (azimuth == null) {
                    Text("لا يدعم جهازك مستشعر البوصلة أو يحتاج إلى معايرة.", textAlign = TextAlign.Center)
                } else {
                    Box(contentAlignment = Alignment.Center, modifier = Modifier.size(260.dp)) {
                        Surface(shape = androidx.compose.foundation.shape.CircleShape, color = MaterialTheme.colorScheme.primary, modifier = Modifier.fillMaxSize()) {}
                        Surface(shape = androidx.compose.foundation.shape.CircleShape, color = MaterialTheme.colorScheme.background, modifier = Modifier.size(205.dp)) {}
                        Text("الكعبة", modifier = Modifier.graphicsLayer(rotationZ = relative).align(Alignment.TopCenter).padding(top = 22.dp), color = MaterialTheme.colorScheme.secondary, fontWeight = FontWeight.Bold)
                        Icon(Icons.Default.Navigation, contentDescription = "اتجاه القبلة", tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(80.dp).graphicsLayer(rotationZ = relative))
                        Text("${bearing.roundToInt()}°", fontSize = 28.sp, fontWeight = FontWeight.Bold, modifier = Modifier.align(Alignment.BottomCenter).padding(bottom = 24.dp))
                    }
                    Spacer(Modifier.height(16.dp))
                    Text("اتجاه القبلة من موقعك: ${bearing.roundToInt()}°", fontWeight = FontWeight.SemiBold)
                }
            }
        }
    }
}

private fun getLastLocation(context: Context): Pair<Double, Double>? {
    val fine = ContextCompat.checkSelfPermission(context, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED
    val coarse = ContextCompat.checkSelfPermission(context, Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED
    if (!fine && !coarse) return null
    val manager = context.getSystemService(Context.LOCATION_SERVICE) as LocationManager
    val candidates = listOf(LocationManager.GPS_PROVIDER, LocationManager.NETWORK_PROVIDER)
    return candidates.firstNotNullOfOrNull { provider ->
        runCatching { manager.getLastKnownLocation(provider) }.getOrNull()?.let { it.latitude to it.longitude }
    }
}

@Composable
private fun MoreScreen(darkTheme: Boolean, onDarkModeChange: (Boolean) -> Unit) {
    val context = LocalContext.current
    var tasbeeh by remember { mutableStateOf(TasbeehStateEntity()) }
    LaunchedEffect(Unit) { tasbeeh = (context.applicationContext as MishkatApplication).repository.getTasbeeh() }
    val scope = rememberCoroutineScope()
    Column(Modifier.fillMaxSize()) {
        Header("المزيد", "الإعدادات والمصادر")
        LazyColumn(contentPadding = PaddingValues(horizontal = 20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            item {
                Surface(shape = RoundedCornerShape(22.dp), color = MaterialTheme.colorScheme.surface, modifier = Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(18.dp)) {
                        Text("المظهر", fontWeight = FontWeight.Bold)
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text("الوضع الليلي", Modifier.weight(1f))
                            Switch(checked = darkTheme, onCheckedChange = onDarkModeChange)
                        }
                    }
                }
            }
            item {
                Surface(shape = RoundedCornerShape(22.dp), color = MaterialTheme.colorScheme.surface, modifier = Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(18.dp)) {
                        Text("السبحة الإلكترونية", fontWeight = FontWeight.Bold, fontSize = 20.sp)
                        Spacer(Modifier.height(10.dp))
                        Text(tasbeeh.phrase, fontSize = 26.sp, color = MaterialTheme.colorScheme.primary, modifier = Modifier.fillMaxWidth(), textAlign = TextAlign.Center)
                        Text("${tasbeeh.count} / ${tasbeeh.target}", fontSize = 34.sp, fontWeight = FontWeight.Bold, modifier = Modifier.fillMaxWidth(), textAlign = TextAlign.Center)
                        Spacer(Modifier.height(10.dp))
                        Button(onClick = {
                            val next = tasbeeh.copy(count = if (tasbeeh.count >= tasbeeh.target) 0 else tasbeeh.count + 1)
                            tasbeeh = next
                            scope.launch { (context.applicationContext as MishkatApplication).repository.saveTasbeeh(next) }
                        }, modifier = Modifier.fillMaxWidth().height(58.dp)) { Text("تسبيح") }
                    }
                }
            }
            item {
                Surface(shape = RoundedCornerShape(22.dp), color = MaterialTheme.colorScheme.surface, modifier = Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(18.dp)) {
                        Text("حول مِشكاة", fontWeight = FontWeight.Bold, fontSize = 20.sp)
                        Spacer(Modifier.height(6.dp))
                        Text("تطبيق إسلامي Offline-First يركز على القرآن والأذكار والصلاة والقبلة والسبحة، مع حفظ بيانات المستخدم محليًا.", color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f))
                        Spacer(Modifier.height(12.dp))
                        Text("المصادر", fontWeight = FontWeight.Bold)
                        Text("القرآن: Tanzil Project • الأذكار: حصن المسلم (بيانات مرخصة في المصدر المستخدم).", color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f))
                    }
                }
            }
        }
    }
}

@Composable
private fun LoadingContent(text: String) {
    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { Column(horizontalAlignment = Alignment.CenterHorizontally) {
        CircularProgressIndicator(color = MaterialTheme.colorScheme.primary)
        Spacer(Modifier.height(12.dp))
        Text(text, textAlign = TextAlign.Center)
    } }
}
