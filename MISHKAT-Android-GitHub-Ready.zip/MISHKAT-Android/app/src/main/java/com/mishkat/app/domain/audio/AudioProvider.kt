package com.mishkat.app.domain.audio

import android.content.Context

/**
 * Contract for local/offline recordings. A future licensed Alafasy pack can be
 * plugged in without changing the UI/data model.
 */
interface AudioProvider {
    fun uriFor(trackId: String): String?
}

class LocalAssetAudioProvider(private val context: Context) : AudioProvider {
    override fun uriFor(trackId: String): String? {
        val safeId = trackId.replace(Regex("[^A-Za-z0-9._-]"), "_")
        val candidates = listOf("audio/$safeId.mp3", "audio/$safeId.m4a", "audio/$safeId.ogg")
        return candidates.firstOrNull { path ->
            runCatching { context.assets.open(path).use { true } }.getOrDefault(false)
        }
    }
}

object AudioCatalog {
    const val ALAFASY = "Alafasy"
}
