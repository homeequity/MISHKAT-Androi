package com.mishkat.app.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val LightColors = lightColorScheme(
    primary = Color(0xFF0F5C5A),
    onPrimary = Color.White,
    primaryContainer = Color(0xFFD7ECE7),
    onPrimaryContainer = Color(0xFF082F2E),
    secondary = Color(0xFFC9A961),
    background = Color(0xFFEEF6F2),
    surface = Color(0xFFF7FBF9),
    surfaceContainer = Color(0xFFE4F0EB),
    onBackground = Color(0xFF10201D),
    onSurface = Color(0xFF10201D),
    outline = Color(0xFF7E908A)
)

private val DarkColors = darkColorScheme(
    primary = Color(0xFF73D0C8),
    onPrimary = Color(0xFF003735),
    primaryContainer = Color(0xFF07514E),
    onPrimaryContainer = Color(0xFFB9F3EC),
    secondary = Color(0xFFC9A961),
    background = Color(0xFF071A18),
    surface = Color(0xFF0A2421),
    surfaceContainer = Color(0xFF10322F),
    onBackground = Color(0xFFE4F4EF),
    onSurface = Color(0xFFE4F4EF),
    outline = Color(0xFF78918B)
)

@Composable
fun MishkatTheme(darkTheme: Boolean = isSystemInDarkTheme(), content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = if (darkTheme) DarkColors else LightColors,
        typography = Typography(),
        content = content
    )
}
