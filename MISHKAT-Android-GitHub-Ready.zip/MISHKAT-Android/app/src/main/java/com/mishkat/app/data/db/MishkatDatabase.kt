package com.mishkat.app.data.db

import android.content.Context
import androidx.room.Database
import androidx.room.Entity
import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Room
import androidx.room.RoomDatabase
import kotlinx.coroutines.flow.Flow

@Entity(tableName = "meta")
data class MetaEntity(@androidx.room.PrimaryKey val key: String, val value: String)

@Entity(tableName = "quran_ayah", primaryKeys = ["surah", "ayah"])
data class QuranAyahEntity(
    val surah: Int,
    val ayah: Int,
    val text: String,
    val page: Int
)

@Entity(tableName = "quran_surah")
data class QuranSurahEntity(
    @androidx.room.PrimaryKey val number: Int,
    val nameArabic: String,
    val revelation: String,
    val ayahCount: Int
)

@Entity(tableName = "azkar_category")
data class AzkarCategoryEntity(
    @androidx.room.PrimaryKey(autoGenerate = true) val id: Long = 0,
    val title: String,
    val audioReference: String? = null,
    val sortOrder: Int
)

@Entity(tableName = "azkar_item")
data class AzkarItemEntity(
    @androidx.room.PrimaryKey(autoGenerate = true) val id: Long = 0,
    val categoryId: Long,
    val text: String,
    val repeatCount: Int,
    val reference: String,
    val sortOrder: Int
)

@Entity(tableName = "bookmark", primaryKeys = ["surah", "ayah"])
data class BookmarkEntity(val surah: Int, val ayah: Int, val createdAt: Long)

@Entity(tableName = "favorite_ayah", primaryKeys = ["surah", "ayah"])
data class FavoriteAyahEntity(val surah: Int, val ayah: Int, val createdAt: Long)

@Entity(tableName = "user_setting")
data class UserSettingEntity(@androidx.room.PrimaryKey val key: String, val value: String)

@Entity(tableName = "tasbeeh_state")
data class TasbeehStateEntity(
    @androidx.room.PrimaryKey val id: Int = 1,
    val phrase: String = "سبحان الله",
    val count: Int = 0,
    val target: Int = 33
)

@Dao
interface MetaDao {
    @Query("SELECT value FROM meta WHERE `key` = :key LIMIT 1") suspend fun get(key: String): String?
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun put(item: MetaEntity)
}

@Dao
interface QuranDao {
    @Query("SELECT * FROM quran_surah ORDER BY number") fun observeSurahs(): Flow<List<QuranSurahEntity>>
    @Query("SELECT * FROM quran_ayah WHERE surah = :surah ORDER BY ayah") fun observeAyahs(surah: Int): Flow<List<QuranAyahEntity>>
    @Query("SELECT * FROM quran_ayah WHERE text LIKE '%' || :query || '%' ORDER BY surah, ayah LIMIT 100") suspend fun search(query: String): List<QuranAyahEntity>
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun insertSurahs(items: List<QuranSurahEntity>)
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun insertAyahs(items: List<QuranAyahEntity>)
}

@Dao
interface AzkarDao {
    @Query("SELECT * FROM azkar_category ORDER BY sortOrder") fun observeCategories(): Flow<List<AzkarCategoryEntity>>
    @Query("SELECT * FROM azkar_item WHERE categoryId = :categoryId ORDER BY sortOrder") fun observeItems(categoryId: Long): Flow<List<AzkarItemEntity>>
    @Query("SELECT * FROM azkar_item WHERE text LIKE '%' || :query || '%' ORDER BY categoryId, sortOrder LIMIT 100") suspend fun search(query: String): List<AzkarItemEntity>
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun insertCategories(items: List<AzkarCategoryEntity>): List<Long>
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun insertItems(items: List<AzkarItemEntity>)
    @Query("SELECT COUNT(*) FROM azkar_category") suspend fun categoryCount(): Int
}

@Dao
interface UserDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun saveBookmark(item: BookmarkEntity)
    @Query("DELETE FROM bookmark WHERE surah = :surah AND ayah = :ayah") suspend fun deleteBookmark(surah: Int, ayah: Int)
    @Query("SELECT EXISTS(SELECT 1 FROM bookmark WHERE surah = :surah AND ayah = :ayah)") suspend fun hasBookmark(surah: Int, ayah: Int): Boolean
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun saveFavorite(item: FavoriteAyahEntity)
    @Query("DELETE FROM favorite_ayah WHERE surah = :surah AND ayah = :ayah") suspend fun deleteFavorite(surah: Int, ayah: Int)
    @Query("SELECT EXISTS(SELECT 1 FROM favorite_ayah WHERE surah = :surah AND ayah = :ayah)") suspend fun hasFavorite(surah: Int, ayah: Int): Boolean
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun saveSetting(item: UserSettingEntity)
    @Query("SELECT value FROM user_setting WHERE `key` = :key LIMIT 1") suspend fun getSetting(key: String): String?
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun saveTasbeeh(item: TasbeehStateEntity)
    @Query("SELECT * FROM tasbeeh_state WHERE id = 1 LIMIT 1") suspend fun getTasbeeh(): TasbeehStateEntity?
}

@Database(
    entities = [MetaEntity::class, QuranAyahEntity::class, QuranSurahEntity::class, AzkarCategoryEntity::class, AzkarItemEntity::class, BookmarkEntity::class, FavoriteAyahEntity::class, UserSettingEntity::class, TasbeehStateEntity::class],
    version = 1,
    exportSchema = true
)
abstract class MishkatDatabase : RoomDatabase() {
    abstract fun metaDao(): MetaDao
    abstract fun quranDao(): QuranDao
    abstract fun azkarDao(): AzkarDao
    abstract fun userDao(): UserDao

    companion object {
        @Volatile private var INSTANCE: MishkatDatabase? = null
        fun get(context: Context): MishkatDatabase = INSTANCE ?: synchronized(this) {
            INSTANCE ?: Room.databaseBuilder(context, MishkatDatabase::class.java, "mishkat.db")
                .build().also { INSTANCE = it }
        }
    }
}
