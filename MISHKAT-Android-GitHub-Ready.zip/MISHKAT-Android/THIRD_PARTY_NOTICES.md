# Third-party content notices

## Quran text
Source: Tanzil Project – https://tanzil.net/
Text release: Version 1.1.
License/terms: Creative Commons Attribution 3.0 as described by Tanzil; verbatim copying/distribution is permitted under the stated terms, but changing the text is not allowed. The source must be clearly indicated and a link to tanzil.net must be provided.

## Hisn al-Muslim data
Source repository: https://github.com/asellam/HisnElMuslim
The current public repository identifies an MIT license and contains the whole book as JSON. The build removes source audio URLs from the packaged dataset unless a recording has a separate verified redistribution right.

## Audio
No Sheikh Mishary Rashid Alafasy recording is bundled by default. Add recordings only after confirming a license that permits redistribution inside the APK.
