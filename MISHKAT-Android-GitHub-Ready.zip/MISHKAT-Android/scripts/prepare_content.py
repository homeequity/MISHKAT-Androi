#!/usr/bin/env python3
"""Fetch and validate third-party Islamic content at build time.

No placeholder Quran/azkar data is committed. The generated files are build artifacts
and are only produced after downloading from the documented sources.
"""
from __future__ import annotations

import json
import re
import sys
from pathlib import Path
from urllib.request import Request, urlopen
from urllib.parse import urlencode
from xml.etree import ElementTree as ET

ROOT = Path(__file__).resolve().parents[1]
ASSETS = ROOT / "app" / "src" / "main" / "assets"
ASSETS.mkdir(parents=True, exist_ok=True)

TANZIL_DOWNLOAD = "https://tanzil.net/pub/download/index.php"
TANZIL_META = "https://tanzil.net/res/text/metadata/quran-data.xml"
HISN_URL = "https://raw.githubusercontent.com/asellam/HisnElMuslim/master/hisn.json"
HISN_LICENSE_URL = "https://raw.githubusercontent.com/asellam/HisnElMuslim/master/LICENSE.md"

SURAH_NAMES = [
    "الفاتحة", "البقرة", "آل عمران", "النساء", "المائدة", "الأنعام", "الأعراف", "الأنفال", "التوبة", "يونس",
    "هود", "يوسف", "الرعد", "إبراهيم", "الحجر", "النحل", "الإسراء", "الكهف", "مريم", "طه",
    "الأنبياء", "الحج", "المؤمنون", "النور", "الفرقان", "الشعراء", "النمل", "القصص", "العنكبوت", "الروم",
    "لقمان", "السجدة", "الأحزاب", "سبأ", "فاطر", "يس", "الصافات", "ص", "الزمر", "غافر",
    "فصلت", "الشورى", "الزخرف", "الدخان", "الجاثية", "الأحقاف", "محمد", "الفتح", "الحجرات", "ق",
    "الذاريات", "الطور", "النجم", "القمر", "الرحمن", "الواقعة", "الحديد", "المجادلة", "الحشر", "الممتحنة",
    "الصف", "الجمعة", "المنافقون", "التغابن", "الطلاق", "التحريم", "الملك", "القلم", "الحاقة", "المعارج",
    "نوح", "الجن", "المزمل", "المدثر", "القيامة", "الإنسان", "المرسلات", "النبأ", "النازعات", "عبس",
    "التكوير", "الانفطار", "المطففين", "الانشقاق", "البروج", "الطارق", "الأعلى", "الغاشية", "الفجر", "البلد",
    "الشمس", "الليل", "الضحى", "الشرح", "التين", "العلق", "القدر", "البينة", "الزلزلة", "العاديات",
    "القارعة", "التكاثر", "العصر", "الهمزة", "الفيل", "قريش", "الماعون", "الكوثر", "الكافرون", "النصر",
    "المسد", "الإخلاص", "الفلق", "الناس"
]


def fetch(url: str, *, data: bytes | None = None, headers: dict[str, str] | None = None) -> bytes:
    req = Request(url, data=data, headers=headers or {"User-Agent": "MISHKAT-build/1.0"})
    with urlopen(req, timeout=60) as response:
        return response.read()


def write_json(path: Path, value: object) -> None:
    path.write_text(json.dumps(value, ensure_ascii=False, separators=(",", ":")), encoding="utf-8")


def parse_quran(text: str) -> list[dict]:
    ayahs: list[dict] = []
    for raw in text.splitlines():
        line = raw.strip("\ufeff\r\n")
        if not line or line.startswith("#"):
            continue
        parts = line.split("|", 2)
        if len(parts) != 3:
            continue
        try:
            surah = int(parts[0])
            ayah = int(parts[1])
        except ValueError:
            continue
        qtext = parts[2]
        if 1 <= surah <= 114 and ayah > 0 and qtext:
            ayahs.append({"surah": surah, "ayah": ayah, "text": qtext, "page": 0})

    if len(ayahs) != 6236:
        raise RuntimeError(f"Unexpected Quran ayah count: {len(ayahs)} (expected 6236).")
    if sorted({a["surah"] for a in ayahs}) != list(range(1, 115)):
        raise RuntimeError("Quran data does not contain all 114 surahs.")
    return ayahs


def enrich_pages(ayahs: list[dict], xml_bytes: bytes) -> None:
    try:
        root = ET.fromstring(xml_bytes)
    except ET.ParseError:
        return

    # Tanzil metadata exposes page partitioning. Its XML schema is intentionally
    # read conservatively because small metadata revisions should not block a build.
    page_map: dict[tuple[int, int], int] = {}
    current_page = 1
    surah_starts: dict[int, int] = {}
    for elem in root.iter():
        if elem.tag.lower().endswith("sura"):
            attrs = {k.lower(): v for k, v in elem.attrib.items()}
            if "index" in attrs and "start" in attrs:
                try:
                    surah_starts[int(attrs["index"])] = int(attrs["start"])
                except ValueError:
                    pass
        elif elem.tag.lower().endswith("page"):
            attrs = {k.lower(): v for k, v in elem.attrib.items()}
            try:
                current_page = int(attrs.get("index") or attrs.get("page") or current_page)
            except ValueError:
                pass
    if not surah_starts:
        return

    # If the metadata format contains explicit ayah ranges, use them.
    for elem in root.iter():
        attrs = {k.lower(): v for k, v in elem.attrib.items()}
        if "sura" in attrs and "aya" in attrs and ("page" in attrs or "index" in attrs):
            try:
                s = int(attrs["sura"])
                a = int(attrs["aya"])
                p = int(attrs.get("page") or attrs.get("index"))
            except ValueError:
                continue
            if 1 <= s <= 114 and a > 0 and 1 <= p <= 604:
                page_map[(s, a)] = p

    if page_map:
        for item in ayahs:
            item["page"] = page_map.get((item["surah"], item["ayah"]), 0)


def build_quran() -> None:
    form = urlencode({
        "quranType": "uthmani",
        "outType": "txt-2",
        "marks": "true",
        "sajdah": "true",
        "rub": "true",
        "stanween": "true",
        "tatweel": "true",
        "agree": "true",
    }).encode("utf-8")
    raw = fetch(TANZIL_DOWNLOAD, data=form, headers={"Content-Type": "application/x-www-form-urlencoded", "User-Agent": "MISHKAT-build/1.0"})
    text = raw.decode("utf-8-sig")
    ayahs = parse_quran(text)

    # Optional metadata enrichment for Medina Mushaf page numbers.
    try:
        enrich_pages(ayahs, fetch(TANZIL_META))
    except Exception:
        pass

    counts = {s: 0 for s in range(1, 115)}
    for a in ayahs:
        counts[a["surah"]] += 1
    surahs = []
    for s in range(1, 115):
        surahs.append({
            "number": s,
            "nameArabic": SURAH_NAMES[s - 1],
            "revelation": "مكية" if s not in {2,3,4,5,8,9,13,24,33,47,48,49,55,57,58,59,60,61,62,63,64,65,66,76,98,110} else "مدنية",
            "ayahCount": counts[s],
        })
    if sum(counts.values()) != 6236:
        raise RuntimeError("Quran counts do not total 6236.")
    write_json(ASSETS / "quran_seed.json", {"version": "Tanzil 1.1", "surahs": surahs, "ayahs": ayahs})


def build_azkar() -> None:
    raw = fetch(HISN_URL)
    data = json.loads(raw.decode("utf-8"))
    if not isinstance(data, dict) or not data:
        raise RuntimeError("Hisn al-Muslim source returned no categories.")
    category_count = 0
    item_count = 0
    for title, category in data.items():
        if not isinstance(category, dict) or not isinstance(category.get("Adhkar"), list):
            raise RuntimeError(f"Invalid Hisn category: {title}")
        category_count += 1
        for item in category["Adhkar"]:
            if not isinstance(item, dict) or not item.get("Text"):
                raise RuntimeError(f"Invalid Hisn item in category: {title}")
            item_count += 1
    if category_count < 100 or item_count < 500:
        raise RuntimeError(f"Hisn dataset unexpectedly small: {category_count} categories, {item_count} items.")

    # Strip audio URLs from the source package unless/ until a recording is verified
    # as redistributable. Text, count and reference are retained verbatim.
    normalized = {}
    for title, category in data.items():
        normalized[title] = {
            "Adhkar": [
                {
                    "Text": item["Text"],
                    "Count": item.get("Count", 1),
                    "Reference": item.get("Reference", ""),
                }
                for item in category.get("Adhkar", [])
            ]
        }
    write_json(ASSETS / "azkar_seed.json", normalized)
    try:
        (ASSETS / "hisn_data_LICENSE.md").write_bytes(fetch(HISN_LICENSE_URL))
    except Exception:
        (ASSETS / "hisn_data_LICENSE.md").write_text("Source: https://github.com/asellam/HisnElMuslim\nLicense: MIT (verify current repository license before redistribution).\n", encoding="utf-8")


def main() -> int:
    print("[MISHKAT] Preparing Quran + Hisn al-Muslim content...")
    build_quran()
    build_azkar()
    print("[MISHKAT] Content preparation complete.")
    return 0


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except Exception as exc:
        print(f"[MISHKAT] ERROR: {exc}", file=sys.stderr)
        raise
